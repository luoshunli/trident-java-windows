package org.tron.trident.abi.datatypes.generated;

import org.tron.trident.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.tron.trident.codegen.AbiTypesGenerator in the
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes29 extends Bytes {
    public static final Bytes29 DEFAULT = new Bytes29(new byte[29]);

    public Bytes29(byte[] value) {
        super(29, value);
    }
}
