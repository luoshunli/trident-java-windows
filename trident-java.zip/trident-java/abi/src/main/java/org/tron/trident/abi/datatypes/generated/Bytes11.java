package org.tron.trident.abi.datatypes.generated;

import org.tron.trident.abi.datatypes.Bytes;

/**
 * Auto generated code.
 * <p><strong>Do not modifiy!</strong>
 * <p>Please use org.tron.trident.codegen.AbiTypesGenerator in the
 * <a href="https://github.com/web3j/web3j/tree/master/codegen">codegen module</a> to update.
 */
public class Bytes11 extends Bytes {
    public static final Bytes11 DEFAULT = new Bytes11(new byte[11]);

    public Bytes11(byte[] value) {
        super(11, value);
    }
}
